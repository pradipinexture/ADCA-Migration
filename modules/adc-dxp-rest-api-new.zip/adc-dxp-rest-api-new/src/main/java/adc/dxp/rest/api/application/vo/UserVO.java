package adc.dxp.rest.api.application.vo;

import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.util.Validator;

import java.util.Date;
import java.util.List;

/**
 * Value Object for User data to be returned by the REST API.
 * This separates the internal Liferay User model from what's exposed in the API.
 */
public class UserVO {
    private long userId;
    private long companyId;
    private String screenName;
    private String emailAddress;
    private String firstName;
    private String middleName;
    private String lastName;
    private String fullName;
    private String jobTitle;
    private String languageId;
    private Date createDate;
    private Date modifiedDate;
    private Date lastLoginDate;
    private String portraitURL;
    private List<ContactVO> contacts;

    public UserVO() {
    }

    public UserVO(User user) {
        if (user != null) {
            this.userId = user.getUserId();
            this.companyId = user.getCompanyId();
            this.screenName = user.getScreenName();
            this.emailAddress = user.getEmailAddress();
            this.firstName = user.getFirstName();
            this.middleName = user.getMiddleName();
            this.lastName = user.getLastName();
            this.fullName = user.getFullName();
            this.jobTitle = user.getJobTitle();
            this.languageId = user.getLanguageId();
            this.createDate = user.getCreateDate();
            this.modifiedDate = user.getModifiedDate();
            this.lastLoginDate = user.getLastLoginDate();
        }
    }

    /**
     * Complement user data with additional information that isn't directly
     * available in the User model.
     */
    public void complementValues() {
        // The implementation depends on what additional information you want to include
        // For example, set portrait URL or load contact information
        // This method would be implemented with your specific business requirements
    }

    // Getters and Setters

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public String getScreenName() {
        return screenName;
    }

    public void setScreenName(String screenName) {
        this.screenName = screenName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getLanguageId() {
        return languageId;
    }

    public void setLanguageId(String languageId) {
        this.languageId = languageId;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Date getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(Date lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public String getPortraitURL() {
        return portraitURL;
    }

    public void setPortraitURL(String portraitURL) {
        this.portraitURL = portraitURL;
    }

    public List<ContactVO> getContacts() {
        return contacts;
    }

    public void setContacts(List<ContactVO> contacts) {
        this.contacts = contacts;
    }
}