package adc.dxp.rest.api.application;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.jaxrs.whiteboard.JaxrsWhiteboardConstants;
import javax.ws.rs.core.Application;
import java.util.Collections;
import java.util.Set;

@Component(
        property = {
                "osgi.jaxrs.application.base=/adc-dxp-services",
                "osgi.jaxrs.extension.select=(osgi.jaxrs.name=Liferay.Vulcan)",
                "osgi.jaxrs.name=Liferay.Services",
                "jaxrs.application=true",
                "auth.verifier.guest.allowed=true",
                "auth.verifier.BasicAuthHeaderAuthVerifier.basic_auth=true"
        },
        service = Application.class,
        immediate = true,
        configurationPolicy = ConfigurationPolicy.OPTIONAL,
        configurationPid = "adc.dxp.rest.api.application.AdcDxpRestApiConfiguration"
)
public class AdcDxpRestApiApplication extends Application {

    public AdcDxpRestApiConfiguration _dxpRESTConfiguration;

    // You can override getSingletons() or getClasses() to register your resources

    @Override
    public Set<Object> getSingletons() {
        return Collections.emptySet();
    }
}