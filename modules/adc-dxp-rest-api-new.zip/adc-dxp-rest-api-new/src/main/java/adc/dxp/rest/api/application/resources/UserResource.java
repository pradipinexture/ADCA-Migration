package adc.dxp.rest.api.application.resources;

import adc.dxp.rest.api.application.vo.UserVO;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.vulcan.pagination.Page;
import com.liferay.portal.vulcan.pagination.Pagination;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Component(
        property = {
                "osgi.jaxrs.application.select=(osgi.jaxrs.name=Liferay.Services)",
                "osgi.jaxrs.resource=true"
        },
        scope = ServiceScope.PROTOTYPE,
        service = UserResource.class
)
@Path("/users")
@Tag(name = "User")
public class UserResource {


    @Reference
    private UserLocalService _userLocalService;

    @Reference
    private Portal _portal;

    private static final Log _log = LogFactoryUtil.getLog(UserResource.class);

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Get all users")
    public Page<User> getUsers(@QueryParam("page") int page, @QueryParam("pageSize") int pageSize) {
        Pagination pagination = Pagination.of(page, pageSize);
        return Page.of(_userLocalService.getUsers(
                pagination.getStartPosition(), pagination.getEndPosition()));
    }

    @GET
    @Path("/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Get user by ID")
    public User getUser(@PathParam("userId") long userId) throws Exception {
        return _userLocalService.getUser(userId);
    }

    @GET
    @Path("/screen-names/{screenName}")
    @Operation(description = "Get a user by screen name.")
    @Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "screenName")})
    @Produces(MediaType.APPLICATION_JSON)
    public UserVO getByScreenName(
            @Parameter(hidden = true) @PathParam("screenName") String screenName,
            @Context HttpServletRequest request) throws PortalException {
        _log.debug("Get user by screen name " + screenName);

        long companyId = _portal.getCompanyId(request);
        User userTmp = _userLocalService.fetchUserByScreenName(companyId, screenName);

        if (userTmp == null) {
            throw new NotFoundException("User with screen name " + screenName + " not found");
        }

        User user = _userLocalService.fetchUser(userTmp.getUserId());
        UserVO result = new UserVO(user);
        result.complementValues();
        result.setContacts(null);
        return result;
    }

    private long getCompanyId(HttpServletRequest request) {
        return _portal.getCompanyId(request);
    }
}