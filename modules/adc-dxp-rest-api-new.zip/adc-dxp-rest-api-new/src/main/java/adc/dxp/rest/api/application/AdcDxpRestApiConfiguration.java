package adc.dxp.rest.api.application;

import aQute.bnd.annotation.metatype.Meta;
import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

@ExtendedObjectClassDefinition(category = "api")
@Meta.OCD(
        id = "adc.dxp.rest.api.application.AdcDxpRestApiConfiguration",
        localization = "content/Language",
        name = "adc-dxp-rest-api-configuration-name"
)
public interface AdcDxpRestApiConfiguration {

    @Meta.AD(deflt = "true", required = false)
    public boolean enableApiEndpoints();

    @Meta.AD(deflt = "1000", required = false)
    public int maxResultLimit();
}