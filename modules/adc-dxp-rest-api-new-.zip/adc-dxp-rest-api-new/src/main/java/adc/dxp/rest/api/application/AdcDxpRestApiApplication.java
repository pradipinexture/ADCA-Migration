package adc.dxp.rest.api.application;

import adc.dxp.rest.api.application.resources.NewsResource;
import adc.dxp.rest.api.application.resources.UserResource;
import com.liferay.portal.kernel.util.Portal;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.jaxrs.whiteboard.JaxrsWhiteboardConstants;
import javax.ws.rs.core.Application;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Component(
        property = {
                "osgi.jaxrs.application.base=/adc-dxp-services",
                "osgi.jaxrs.extension.select=(osgi.jaxrs.name=Liferay.Vulcan)",
                "osgi.jaxrs.name=ADC.Services",
                "jaxrs.application=true",
                "auth.verifier.guest.allowed=true",
                "auth.verifier.BasicAuthHeaderAuthVerifier.basic_auth=true"
        },
        service = Application.class,
        immediate = true,
        configurationPolicy = ConfigurationPolicy.OPTIONAL,
        configurationPid = "adc.dxp.rest.api.application.AdcDxpRestApiConfiguration"
)
public class AdcDxpRestApiApplication extends Application {

    public AdcDxpRestApiConfiguration _dxpRESTConfiguration;
    @Reference
    private Portal _portal;
    @Reference
    private UserResource _userResource;
    /*
    @Reference
    private NewsResource _newsResource;*/
    @Override
    public Set<Object> getSingletons() {
        Set<Object> singletons = new HashSet<>();
        singletons.add(_userResource);
        //singletons.add(_newsResource);
        return singletons;
    }
}