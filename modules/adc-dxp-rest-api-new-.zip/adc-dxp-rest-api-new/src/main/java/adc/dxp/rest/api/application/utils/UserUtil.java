package adc.dxp.rest.api.application.utils;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.model.role.RoleConstants;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
public class UserUtil {
    private static final Log _log = LogFactoryUtil.getLog(UserUtil.class);

    /**
     * Gets the current user from the request
     *
     * @param request the HTTP servlet request
     * @return the current user
     * @throws PortalException if unable to determine the current user
     */
    public static User getCurrentUser(HttpServletRequest request) throws PortalException {
        try {
            // Try to get user from request
            User user = PortalUtil.getUser(request);

            if (user != null) {
                return user;
            }

            // If no user found in request, find an administrator
            long companyId = PortalUtil.getCompanyId(request);

            // Get the administrator role
            Role adminRole = RoleLocalServiceUtil.getRole(companyId, RoleConstants.ADMINISTRATOR);

            // Get users with admin role
            List<User> adminUsers = UserLocalServiceUtil.getRoleUsers(adminRole.getRoleId(), 0, 1);

            if (!adminUsers.isEmpty()) {
                return adminUsers.get(0);
            }

            // If no admin users found, use the default test@liferay.com if it exists
            try {
                return UserLocalServiceUtil.getUserByEmailAddress(companyId, "test@liferay.com");
            } catch (Exception e) {
                _log.warn("Could not find test@liferay.com user", e);
            }

            // Last resort: return the first user found for this company
            List<User> users = UserLocalServiceUtil.getCompanyUsers(companyId, 0, 1);
            if (!users.isEmpty()) {
                return users.get(0);
            }

            throw new PortalException("No users found in the system");

        } catch (Exception e) {
            _log.error("Error getting current user", e);
            throw new PortalException("Unable to determine current user", e);
        }
    }
}
