package adc.dxp.rest.api.application.resources;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import adc.dxp.rest.api.application.data.vo.UserVO;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.model.Image;
import com.liferay.portal.kernel.service.ImageLocalServiceUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.webserver.WebServerServletTokenUtil;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ServiceScope;

import com.liferay.portal.kernel.dao.orm.Conjunction;
import com.liferay.portal.kernel.dao.orm.Disjunction;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.OrderFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchContextFactory;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.filter.Filter;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.vulcan.pagination.Page;
import com.liferay.portal.vulcan.pagination.Pagination;

import adc.dxp.rest.api.application.utils.Constants;
import adc.dxp.rest.api.application.utils.PageUtils;
import adc.dxp.rest.api.application.utils.RequestUtil;
import adc.dxp.rest.api.application.utils.UserUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.tags.Tag;


@Component(
        property = {
                "osgi.jaxrs.application.select=(osgi.jaxrs.name=ADC.Services)",
                "osgi.jaxrs.resource=true"
        },
        scope = ServiceScope.PROTOTYPE,
        service = UserResource.class
)
@Path("/users")
@Tag(name = "User")
public class UserResource {

    private static final Log _log = LogFactoryUtil.getLog(UserResource.class);

    @Reference
    private UserLocalService _userLocalService;

    @Reference
    private Portal _portal;

    // This is causing a dependency issue - switching to use normal utility classes instead
    //@Reference(target = "(component.name=adc.dxp.rest.api.application.AdcDxpRestApiApplication)")
    //private AdcDxpRestApiApplication _app;

    /**
     * Get current user
     */
    @GET
    @Path("/currentUser")
    @Operation(description = "Get current user")
    @Produces(MediaType.APPLICATION_JSON)
    public User getCurrentUser(
            @Context HttpServletRequest request,
            @HeaderParam(Constants.HEADER_GROUP_ID) long groupId) throws PortalException {

        User currentUser = UserUtil.getCurrentUser(request);
        _log.debug("Current user: " + currentUser.getFullName());

        // Getting portrait URL in Liferay 7.4
        ThemeDisplay themeDisplay = RequestUtil.getTheme(request);

        try {
            String portraitURL = currentUser.getPortraitURL(themeDisplay);
            _log.debug("Portrait URL: " + portraitURL);
        } catch (Exception e) {
            _log.error("Error getting portrait URL", e);
        }

        return currentUser;
    }

    /**
     * Search users
     */
    @GET
    @Path("/search")
    @Operation(description = "Search users.")
    @Parameters(value = {
            @Parameter(in = ParameterIn.QUERY, name = "keywords"),
            @Parameter(in = ParameterIn.QUERY, name = "pageSize")
    })
    @Produces(MediaType.APPLICATION_JSON)
    public Page<UserVO> searchUsers(
            @Parameter(hidden = true) @QueryParam("keywords") String keywords,
            @QueryParam("pageSize") Integer pageSize,
            @Context Filter filter,
            @Context Pagination pagination,
            @Context Sort[] sorts,
            @Context HttpServletRequest request) throws PortalException {

        _log.debug("Searching users with keywords: " + keywords);

        User currentUser = UserUtil.getCurrentUser(request);
        SearchContext searchContext = SearchContextFactory.getInstance(request);
        searchContext.setCompanyId(currentUser.getCompanyId());

        DynamicQuery query = _userLocalService.dynamicQuery();
        query.add(PropertyFactoryUtil.forName("companyId").eq(currentUser.getCompanyId()));
        query.add(PropertyFactoryUtil.forName("status").eq(WorkflowConstants.STATUS_APPROVED));

        if (keywords != null && !keywords.isEmpty()) {
            Conjunction conjunction = RestrictionsFactoryUtil.conjunction();
            Disjunction disjunction = RestrictionsFactoryUtil.disjunction();

            disjunction.add(PropertyFactoryUtil.forName("firstName").like("%" + keywords + "%"));
            disjunction.add(PropertyFactoryUtil.forName("lastName").like("%" + keywords + "%"));
            disjunction.add(PropertyFactoryUtil.forName("screenName").like("%" + keywords + "%"));
            disjunction.add(PropertyFactoryUtil.forName("emailAddress").like("%" + keywords + "%"));

            conjunction.add(disjunction);
            query.add(conjunction);
        }

        OrderByComparator<User> orderByComparator = OrderByComparatorFactoryUtil.create(
                "User_", "firstName", true, "lastName", true);
        query.addOrder(OrderFactoryUtil.asc("firstName"));
        query.addOrder(OrderFactoryUtil.asc("lastName"));

        int start = pagination.getStartPosition();
        int end = pagination.getEndPosition();

        List<User> users = _userLocalService.dynamicQuery(query, start, end, orderByComparator);
        long total = _userLocalService.dynamicQueryCount(query);

        List<UserVO> userVOs = new ArrayList<>();
        for (User user : users) {
            userVOs.add(convertToUserVO(user));
        }

        return PageUtils.createPage(userVOs, pagination, total);
    }

    /**
     * Convert User to UserVO with portrait URL
     */
    private UserVO convertToUserVO(User user) {
        UserVO userVO = new UserVO();
        userVO.setUserId(user.getUserId());
        userVO.setFirstName(user.getFirstName());
        userVO.setLastName(user.getLastName());
        userVO.setScreenName(user.getScreenName());
        userVO.setEmailAddress(user.getEmailAddress());
        userVO.setLanguageId(user.getLanguageId());

        String portraitURL = StringPool.BLANK;
        try {
            if (user.getPortraitId() > 0) {
                Image image = ImageLocalServiceUtil.getImage(user.getPortraitId());
                if (image != null) {
                    String token = WebServerServletTokenUtil.getToken(user.getPortraitId());
                    portraitURL = "/user/" + user.getUserId() + "/portrait?img_id_token=" + token;
                }
            }
        } catch (PortalException e) {
            _log.error("Error getting portrait for user " + user.getUserId(), e);
        }
        userVO.setPortraitURL(portraitURL);

        return userVO;
    }

    /**
     * Returns a user by primary key
     */
    @GET
    @Path("/{id}")
    @Operation(description = "Get a user by primary key.")
    @Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "id")})
    @Produces(MediaType.APPLICATION_JSON)
    public UserVO getUserById(
            @Parameter(hidden = true) @PathParam("id") long id,
            @Context HttpServletRequest request) throws PortalException {

        _log.debug("Get user by id " + id);

        User user = _userLocalService.fetchUser(id);

        if (user == null) {
            throw new PortalException("User with id " + id + " not found");
        }

        UserVO result = new UserVO(user);
        result.complementValues();
        result.setContacts(null);

        return result;
    }

    /**
     * Returns a user by screen name
     */
    @GET
    @Path("/screen-names/{screenName}")
    @Operation(description = "Get a user by screen name.")
    @Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "screenName")})
    @Produces(MediaType.APPLICATION_JSON)
    public UserVO getUserByScreenName(
            @Parameter(hidden = true) @PathParam("screenName") String screenName,
            @Context HttpServletRequest request) throws PortalException {

        _log.debug("Get user by screen name " + screenName);

        long companyId = _portal.getCompanyId(request);
        User userTmp = _userLocalService.fetchUserByScreenName(companyId, screenName);

        if (userTmp == null) {
            throw new PortalException("User with screen name " + screenName + " not found");
        }

        User user = _userLocalService.fetchUser(userTmp.getUserId());

        UserVO result = new UserVO(user);
        result.complementValues();
        result.setContacts(null);

        return result;
    }
}