package adc.dxp.rest.api.application.resources;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.service.JournalArticleLocalServiceUtil;
import com.liferay.journal.util.comparator.ArticleDisplayDateComparator;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.filter.Filter;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.vulcan.pagination.Page;
import com.liferay.portal.vulcan.pagination.Pagination;

import adc.dxp.rest.api.application.AdcDxpRestApiApplication;
import adc.dxp.rest.api.application.data.Category;
import adc.dxp.rest.api.application.data.Promotion;
import adc.dxp.rest.api.application.data.comparator.JournalArticleTitleComparator;
import adc.dxp.rest.api.application.utils.Constants;
import adc.dxp.rest.api.application.utils.PageUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;

/**
 * 
 * Endpoints  of the Promotions
 * 
 * @author luis.correia
 *
 */
@Path("/promotions")
public class PromotionsResource extends BasicResource {
		
	/**
	 * app instance
	 */
	private AdcDxpRestApiApplication _app;
	
	/**
	 * logging instance
	 */
	private static Log _log = LogFactoryUtil.getLog(PromotionsResource.class);

	
	/**
	 * 
	 * Constructor, will be used in AdcDxpRestApiApplication.getSingletons()
	 * 
	 * @param _app
	 */
	public PromotionsResource(AdcDxpRestApiApplication _app) {
		this._app = _app;
	}
	
	@GET
	@Operation(
		description = "Retrieves the list of the Promotions. Results can be paginated, filtered, searched, and sorted."
	)
	@Parameters(
		value = {
			@Parameter(in = ParameterIn.QUERY, name = "search"),
			@Parameter(in = ParameterIn.QUERY, name = "filter"),
			@Parameter(in = ParameterIn.QUERY, name = "page"),
			@Parameter(in = ParameterIn.QUERY, name = "pageSize"),
			@Parameter(in = ParameterIn.QUERY, name = "sort")
		}
	)
	@Path("/search")
	@Produces(MediaType.APPLICATION_JSON)
	public Page<Promotion> search(
			@Parameter(hidden = true) @QueryParam("search") String search,
			@Parameter(hidden = true) @QueryParam("categoryId") String categoryIdParam,
			@Parameter(hidden = true) @QueryParam("startDate") String startDateParam,
			@Parameter(hidden = true) @QueryParam("endDate") String endDateParam,
			@QueryParam("pageSize") Integer pageSize,
			@Context Filter filter, 
			@Context Pagination pagination,
			@Context Sort[] sorts,
			@Context HttpServletRequest request,
			@HeaderParam(Constants.HEADER_GROUP_ID) long groupId)
					throws PortalException {
				
		int paginationSize = pageSize == null ? _app._dxpRESTConfiguration.paginationSize() : pageSize;
		int paginationPage = pagination.getPage();
				
		String languageIdString = request.getHeader("languageId");
						
		long categoryId = categoryIdParam != null && !categoryIdParam.isEmpty() && !categoryIdParam.equalsIgnoreCase("null") ? 
				Long.valueOf(categoryIdParam).longValue() : -1;
						
		long companyId = PortalUtil.getCompanyId(request);
		
		String structureId = StructureResource.getStructure(groupId, Constants.STRUCTURE_PROMOTIONS_EN);
		
		//Date
		Date startDate = null;
		Date endDate = null;
		
		try {
			if (startDateParam != null && !startDateParam.isEmpty()) {
				startDate = new SimpleDateFormat("dd-MM-yyyy").parse(startDateParam);  
			}
			if (endDateParam != null && !endDateParam.isEmpty()) {
				
				endDate = new SimpleDateFormat("dd-MM-yyyy").parse(endDateParam);
//				Calendar calendar = Calendar.getInstance();
//			    calendar.setTime(endDate);
//			    calendar.add(Calendar.HOUR_OF_DAY, 23);
//			    calendar.add(Calendar.MINUTE, 59);
			    
//			    endDate = calendar.getTime();
			    
			}
			
		} catch (ParseException e) {
			// TODO: luis.correia
			e.printStackTrace();
		}
		
		OrderByComparator<JournalArticle> orderByComparator = null;
		
		if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("displayDate")) {
			orderByComparator = new ArticleDisplayDateComparator(!sorts[0].isReverse());	
		}
		
		else if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("title")) {
			orderByComparator = new JournalArticleTitleComparator(!sorts[0].isReverse());	
		}
		
		List<JournalArticle> results = search(companyId, groupId, Collections.emptyList(), 0, search, null, 
				structureId, null, startDate, endDate, 0, null, QueryUtil.ALL_POS, QueryUtil.ALL_POS, orderByComparator);
		
		List<Promotion> lastResults = new ArrayList<>();
		
		for (JournalArticle article: results) {
			
			Promotion promotion = new Promotion(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));
			
			if ((startDate != null && (startDate.before(promotion.getStartDate()) || promotion.getEndDate().before(startDate)))
				||
				(endDate != null && (endDate.before(promotion.getStartDate()) || promotion.getEndDate().before(endDate)))) {
				continue;
			}
			
			AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle",
							article.getResourcePrimKey());
			promotion.setEntryId(assetUtil.getEntryId());
			
			List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
			
			Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
			
			if (firstCategory.isPresent()) {
				AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
				promotion.setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
			}

			if ((categoryIdParam == null || categoryIdParam.equalsIgnoreCase("-1")
					|| Long.compare(categoryId, promotion.getCategory().getCategoryId()) == 0)
					&& (lastResults.indexOf(promotion) == -1)) {
				lastResults.add(promotion);
			}
			
		
		}
		
		//order by category
		if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("category"))
		{
			
			if (!sorts[0].isReverse())
			{
				//asc
				lastResults.sort((promo1, promo2) -> promo1.getCategory().getName().compareTo(promo2.getCategory().getName()));
			}
			else
			{
				//desc
				lastResults.sort((promo1, promo2) -> promo2.getCategory().getName().compareTo(promo1.getCategory().getName()));
			}
		}	
		
		return PageUtils.getPage(lastResults, paginationSize, paginationPage);
	}
	
	/**
	 * 
	 * Returns promotion by id
	 * 
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("/detail")
	@Operation(description = "Get promotion by id")
	@Parameters(
			value = {
				@Parameter(in = ParameterIn.QUERY, name = "id")
			}
		)
	@Produces(MediaType.APPLICATION_JSON)
	public Promotion getPromotionById(
			@Parameter(hidden = true) @QueryParam("id") String idString,
			@Context HttpServletRequest request
			) throws PortalException {

		_log.debug("Call get promotion");

		String groupIdString = request.getHeader("groupId");
		String languageIdString = request.getHeader("languageId");
		
		long groupId = Long.valueOf(groupIdString).longValue();
		
		long id = Long.valueOf(idString).longValue();
		
		String structureId = StructureResource.getStructure(groupId, Constants.STRUCTURE_PROMOTIONS_EN);

		JournalArticle article = JournalArticleLocalServiceUtil.getLatestArticle(id);
		Promotion promotionDetail = new Promotion(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));
		
		AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle", article.getResourcePrimKey());

		_log.debug("JournalArticle: " + article);
		
		_log.debug("article.getResourcePrimKey(): " + article.getResourcePrimKey());
		
		
		List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
		
		Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
		
		if (firstCategory.isPresent()) {
			AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
			//promotionDetail.setCategory(catego.getTitle(languageIdString));
			promotionDetail.setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
			_log.debug("categoryName: " + catego.getName());
		}
		
		if (article == null || !article.getStructureId().equals(structureId)) {
			// TODO: improve this
			_log.debug("Not Found");
			throw new PortalException(javax.ws.rs.core.Response.Status.NOT_FOUND.toString());
		}
		
		return promotionDetail;
	}
}
