package adc.dxp.rest.api.application.utils;

import com.liferay.dynamic.data.mapping.model.DDMStructure;
import com.liferay.dynamic.data.mapping.service.DDMStructureLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.LocaleUtil;

import adc.dxp.rest.api.application.resources.AnnouncementsResource;

/**
 * 
 * @author ricardo.gomes
 *
 */
public class StructureUtil {
	
	/**
	 * logging instance
	 */
	private static Log _log = LogFactoryUtil.getLog(AnnouncementsResource.class);

	
	// TODO: improve this
	/**
	 * 
	 * @param name
	 * @return 
	 * @throws PortalException
	 */
	public static DDMStructure getStructureByNameEn(String name) throws PortalException {
		
		java.util.List<DDMStructure> structures = DDMStructureLocalServiceUtil.getStructures();

		for (DDMStructure s : structures) {
			if (s.getName(LocaleUtil.ENGLISH).equals(name)) {
				return s;
			}
		}

		throw new PortalException("Structure not found");

	}

}
