package adc.dxp.rest.api.application.data.comparator;

import com.liferay.journal.model.JournalArticle;
import com.liferay.portal.kernel.util.OrderByComparator;

public class JournalArticleTitleComparator extends OrderByComparator<JournalArticle>{

	
	public static final String ORDER_BY_ASC =
			"JournalArticleLocalization.title ASC";

		public static final String ORDER_BY_DESC =
			"JournalArticleLocalization.title DESC";

		public static final String[] ORDER_BY_FIELDS = {"urltitle"};

		public JournalArticleTitleComparator() {
			this(false);
		}

		public JournalArticleTitleComparator(boolean ascending) {
			_ascending = ascending;
		}
		
		
		

		@Override
		public int compare(JournalArticle article1, JournalArticle article2) {			
			
			JournalArticle obj1 = (JournalArticle) article1;
		    JournalArticle obj2 = (JournalArticle) article2;

		    int value = obj1.getTitle().toLowerCase().compareTo(obj2.getTitle().toLowerCase());

		    if (_ascending) {
		      return value;
		    } else {
		      return -value;
		    }		
		}

		@Override
		public String getOrderBy() {
			if (_ascending) {
				return ORDER_BY_ASC;
			}

			return ORDER_BY_DESC;
		}

		@Override
		public String[] getOrderByFields() {
			return ORDER_BY_FIELDS;
		}

		@Override
		public boolean isAscending() {
			return _ascending;
		}

		private final boolean _ascending;

}