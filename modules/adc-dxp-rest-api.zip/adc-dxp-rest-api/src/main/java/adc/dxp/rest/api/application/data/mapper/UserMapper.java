package adc.dxp.rest.api.application.data.mapper;

import com.liferay.portal.kernel.model.User;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import adc.dxp.rest.api.application.data.vo.UserVO;

/**
 * 
 * User mapper
 * 
 * @author ricardo.gomes
 *
 */
@Mapper
public interface UserMapper {

    UserMapper INST = Mappers.getMapper(UserMapper.class);

    /**
     * 
     * Converts UserVO to User
     * 
     * @param userVO
     * @return
     */
    User userVOToUser(UserVO  userVO);
	
    /**
     * 
     * Converts User to User
     * 
     * @param user
     * @return
     */
    @Mapping(source = "userId", target = "userId")
    @Mapping(source = "screenName", target = "screenName")
	UserVO userToUserVO(User  user);
    
    

}