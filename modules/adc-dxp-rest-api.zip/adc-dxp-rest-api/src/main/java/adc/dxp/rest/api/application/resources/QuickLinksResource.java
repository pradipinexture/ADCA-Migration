package adc.dxp.rest.api.application.resources;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.service.JournalArticleLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.filter.Filter;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.vulcan.pagination.Page;
import com.liferay.portal.vulcan.pagination.Pagination;
import com.liferay.journal.util.comparator.ArticleDisplayDateComparator;


import adc.dxp.rest.api.application.AdcDxpRestApiApplication;
import adc.dxp.rest.api.application.data.Category;
import adc.dxp.rest.api.application.data.QuickLinks;
import adc.dxp.rest.api.application.data.Ratings;
import adc.dxp.rest.api.application.data.comparator.JournalArticleTitleComparator;
import adc.dxp.rest.api.application.utils.Constants;
import adc.dxp.rest.api.application.utils.PageUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;

@Path("/quick-links")
public class QuickLinksResource extends BasicResource {
		
	/**
	 * app instance
	 */
	private AdcDxpRestApiApplication _app;
	
	/**
	 * logging instance
	 */
	private static Log _log = LogFactoryUtil.getLog(PromotionsResource.class);
	
	/**
	 * 
	 * Constructor, will be used in AdcDxpRestApiApplication.getSingletons()
	 * 
	 * @param _app
	 */
	public QuickLinksResource(AdcDxpRestApiApplication _app) {
		this._app = _app;
	}
	
	@GET
	@Operation(
		description = "Retrieves the list of the Quick Links ordered by current user rating, or default order."
	)
	@Path("/favorites")
	@Produces(MediaType.APPLICATION_JSON)
	public List<QuickLinks> getFavorites(
			@Context Filter filter, 
			@Context Sort[] sorts,
			@Context HttpServletRequest request) throws PortalException {
				
		String groupIdString = request.getHeader("groupId");
		
		long groupId = Long.valueOf(groupIdString).longValue();
		long companyId = PortalUtil.getCompanyId(request);
		
		String structureId = StructureResource.getStructure(groupId, Constants.STRUCTURE_QUICK_LINKS_EN);
		
		List<JournalArticle> results = search(companyId, groupId, Collections.emptyList(), 0,
				null, null, structureId, null, null, null, 0, null, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
		
		//List<QuickLinks> lastResults = new ArrayList<>();
		
		List<QuickLinks> lastResultsUpVoted = new ArrayList<>();
				
		boolean defaultOrder = true;
		
		for (JournalArticle article: results) {
			QuickLinks quickLink = new QuickLinks(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));
			
			Ratings ratings = RatingsResource.getRatingsById(String.valueOf(article.getResourcePrimKey()), request);
			quickLink.setRatings(ratings);
			
			if (ratings.isThumbsUp() && (lastResultsUpVoted.indexOf(quickLink) == -1))
			{
				defaultOrder = false;
				lastResultsUpVoted.add(quickLink);
			}
		
			/*if (lastResults.indexOf(quickLink) == -1)
			{
				lastResults.add(quickLink);
			}*/
        }

		/*if (defaultOrder) {
			// default sort by relevance
			Collections.sort(lastResults);
			
			// return first 5 links
			return lastResults.size() <= 5 ? lastResults : lastResults.subList(0, 5);
		} else {*/
			// sort by alphabetically
			lastResultsUpVoted.sort((link1, link2) -> link1.getTitle().compareTo(link2.getTitle()));
			
			// return first 5 links
			return lastResultsUpVoted.size() <= 5 ? lastResultsUpVoted : lastResultsUpVoted.subList(0, 5);
		//}
	}
	
	@GET
	@Operation(
		description = "Retrieves the list of all Quick Links."
	)
	@Parameters(
			value = {
				@Parameter(in = ParameterIn.QUERY, name = "search"),
				@Parameter(in = ParameterIn.QUERY, name = "filter"),
				@Parameter(in = ParameterIn.QUERY, name = "page"),
				@Parameter(in = ParameterIn.QUERY, name = "pageSize"),
				@Parameter(in = ParameterIn.QUERY, name = "sort")
			}
		)
	@Path("/search")
	@Produces(MediaType.APPLICATION_JSON)
	public Page<QuickLinks> search(
			@Parameter(hidden = true) @QueryParam("search") String search,
			@Parameter(hidden = true) @QueryParam("categoryId") String categoryIdParam,
			@Parameter(hidden = true) @QueryParam("startDate") String startDateParam,
			@Parameter(hidden = true) @QueryParam("endDate") String endDateParam,
			@QueryParam("pageSize") Integer pageSize,
			@Context Filter filter, 
			@Context Pagination pagination,
			@Context Sort[] sorts,
			@Context HttpServletRequest request,
			@HeaderParam(Constants.HEADER_GROUP_ID) long groupId) throws PortalException {
		
		int paginationSize = pageSize == null ? _app._dxpRESTConfiguration.paginationSize() : pageSize;
		int paginationPage = pagination.getPage();
				
		String languageIdString = request.getHeader("languageId");
						
		long categoryId = categoryIdParam != null && !categoryIdParam.isEmpty() && !categoryIdParam.equalsIgnoreCase("null") ? 
				Long.valueOf(categoryIdParam).longValue() : -1;
						
		long companyId = PortalUtil.getCompanyId(request);
		
		String structureId = StructureResource.getStructure(groupId, Constants.STRUCTURE_QUICK_LINKS_EN);
		
		//Date
		Date startDate = null;
		Date endDate = null;
		
		try {
			if (startDateParam != null && !startDateParam.isEmpty()) {
				startDate = new SimpleDateFormat("dd-MM-yyyy").parse(startDateParam);  
			}
			if (endDateParam != null && !endDateParam.isEmpty()) {
				endDate = new SimpleDateFormat("dd-MM-yyyy").parse(endDateParam);  
			}
			
		} catch (ParseException e) {
			// TODO: luis.correia
			e.printStackTrace();
		}
		
		OrderByComparator<JournalArticle> orderByComparator = null;

		if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("displayDate")) {
			orderByComparator = new ArticleDisplayDateComparator(!sorts[0].isReverse());
		}

		else if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("title")) {
			orderByComparator = new JournalArticleTitleComparator(!sorts[0].isReverse());
		}
		
		
		List<JournalArticle> results = search(companyId, groupId, Collections.emptyList(), 0, search, null, 
				structureId, null, startDate, endDate, 0, null, QueryUtil.ALL_POS, QueryUtil.ALL_POS, orderByComparator);
		
		List<QuickLinks> lastResults = new ArrayList<>();
		
		for (JournalArticle article: results) {
			QuickLinks quickLink = new QuickLinks(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));
			
			AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle",
							article.getResourcePrimKey());
			quickLink.setEntryId(assetUtil.getEntryId());
			
			Ratings ratings = RatingsResource.getRatingsById(String.valueOf(article.getResourcePrimKey()), request);
			quickLink.setRatings(ratings);
			
			List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
			
			Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
			
			if (firstCategory.isPresent()) {
				AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
				quickLink.setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
			}
		
			if ((categoryIdParam == null || categoryIdParam.equalsIgnoreCase("-1")
					|| Long.compare(categoryId, quickLink.getCategory().getCategoryId()) == 0)
					&& (lastResults.indexOf(quickLink) == -1)) {
				lastResults.add(quickLink);
			}
		}
		
		return PageUtils.getPage(lastResults, paginationSize, paginationPage);
	}
}
