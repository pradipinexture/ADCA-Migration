package adc.dxp.rest.api.application;


import java.util.List;

import com.liferay.portal.configuration.metatype.annotations.ExtendedObjectClassDefinition;

import aQute.bnd.annotation.metatype.Meta;

/**
 * 
 * This interface is responsible for add and define custom properties in others system settings
 * 
 * @author ricardo.gomes
 *
 */
@ExtendedObjectClassDefinition(category = "LinkConsulting", scope = ExtendedObjectClassDefinition.Scope.SYSTEM	)
@Meta.OCD(
		factory = true,
		id = "adc.dxp.rest.api.application.AdcDxpRestApiConfiguration",
		localization = "content/Language", 
		name = "AdcDxp_REST_Configuration"
)	
public interface AdcDxpRestApiConfiguration {
	
	/**
	 * 
	 * Number of announcements per page
	 * 
	 * @return
	 */
	@Meta.AD(description= "AnnouncementsPerPage", deflt="1", required=false)
	public String announcementsPerPage();
	
	@Meta.AD(description= "PaginationSize", deflt="6", required=false)
	public Integer paginationSize();
	
//	@Meta.AD(description= "calendars", deflt="33715,33645", required=false)
	@Meta.AD(description= "calendars", deflt="", required=false)
	public List<Long> calendars();
	
	@Meta.AD(description= "AnnouncementsPortletID", deflt="adcdxpannouncements", required=false)
	public String announcementsPortletID();
	
	@Meta.AD(description= "PollsPortletID", deflt="com_liferay_polls_web_portlet_PollsDisplayPortlet_INSTANCE_lqPxc8HV1s6G", required=false)
	public String pollsPortletID();

	
}
