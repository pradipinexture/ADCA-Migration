package adc.dxp.rest.api.application.data;

import adc.dxp.rest.api.application.utils.ContentType;

public class Content {

	private ContentType type;

	public Content () {
		
	}
	
	public Content (ContentType type) {
		this.type = type;
	}
	
	// getters + setters
	
	public ContentType getType() {
		return type;
	}

	public void setType(ContentType type) {
		this.type = type;
	}
	
	
	
}
