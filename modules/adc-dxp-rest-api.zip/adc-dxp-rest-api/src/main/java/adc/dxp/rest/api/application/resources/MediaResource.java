package adc.dxp.rest.api.application.resources;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PATCH;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.liferay.announcements.kernel.model.AnnouncementsFlag;
import com.liferay.announcements.kernel.service.AnnouncementsFlagLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.document.library.kernel.model.DLFileEntry;
import com.liferay.document.library.kernel.service.DLFileEntryLocalServiceUtil;
import com.liferay.dynamic.data.mapping.service.DDMStructureLocalServiceUtil;
import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.service.JournalArticleLocalServiceUtil;
import com.liferay.journal.util.comparator.ArticleDisplayDateComparator;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.NestableException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.filter.Filter;
import com.liferay.portal.kernel.util.LocaleUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.vulcan.pagination.Page;
import com.liferay.portal.vulcan.pagination.Pagination;

import adc.dxp.rest.api.application.AdcDxpRestApiApplication;
import adc.dxp.rest.api.application.data.Category;
import adc.dxp.rest.api.application.data.Media;
import adc.dxp.rest.api.application.data.comparator.JournalArticleTitleComparator;
import adc.dxp.rest.api.application.data.vo.GalleryVO;
import adc.dxp.rest.api.application.utils.Constants;
import adc.dxp.rest.api.application.utils.FileUtil;
import adc.dxp.rest.api.application.utils.StructureUtil;
import adc.dxp.rest.api.application.utils.UserUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;

/**
 * 
 * Endpoints of galleries
 * 
 * @author ricardo.gomes
 *
 */
@Path("/medias")
public class MediaResource extends BasicResource {

	/**
	 * logging instance
	 */
	private static Log _log = LogFactoryUtil.getLog(MediaResource.class);

	/**
	 * app instance
	 */
	AdcDxpRestApiApplication _app;

	/**
	 * 
	 * Constructor, will be used in AdcDxpRestApiApplication.getSingletons()
	 * 
	 * @param _app
	 */
	public MediaResource(AdcDxpRestApiApplication _app) {
		this._app = _app;
	}

	/**
	 * 
	 * Returns all Galleries
	 * 
	 * @param isRead  with flag read
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("/galleries")
	@Operation(description = "Get all galleries.")
	@Parameters(value = { @Parameter(in = ParameterIn.QUERY, name = "search"),
			@Parameter(in = ParameterIn.QUERY, name = "filter"),
			@Parameter(in = ParameterIn.QUERY, name = "page"),
			@Parameter(in = ParameterIn.QUERY, name = "pageSize"),
			@Parameter(in = ParameterIn.QUERY, name = "sort") })
	@Produces(MediaType.APPLICATION_JSON)
	public Page<Media> getAllGalleries(@QueryParam("pageSize") Integer pageSize,
			@Context HttpServletRequest request,
			@Parameter(hidden = true) @QueryParam("search") String search,
			@Parameter(hidden = true) @QueryParam("categoryId") String categoryIdParam,
			@Parameter(hidden = true) @QueryParam("startDate") String startDateParam,
			@Parameter(hidden = true) @QueryParam("endDate") String endDateParam,
			@Context Filter filter,
			@Context Pagination pagination,
			@Context Sort[] sorts,
			@HeaderParam(Constants.HEADER_GROUP_ID) long groupId)
			throws PortalException {

		_log.debug("Call all galleries " + groupId);
		showAttr(request);
		_log.debug("-----------------------------");

		String structureId = "";

		long companyId = getCompanyId(request);
		String languageIdString = request.getHeader("languageId");

		long categoryId = categoryIdParam != null && !categoryIdParam.isEmpty() && !categoryIdParam.equalsIgnoreCase("null") ? 
				Long.valueOf(categoryIdParam).longValue() : -1;

		List<com.liferay.dynamic.data.mapping.model.DDMStructure> structures = DDMStructureLocalServiceUtil
				.getStructures();

		for (com.liferay.dynamic.data.mapping.model.DDMStructure structure : structures) {
			_log.debug(structure.getName(LocaleUtil.ENGLISH));
			_log.debug(structure.getGroupId());
			if (structure.getName(LocaleUtil.ENGLISH).equalsIgnoreCase(Constants.STRUCTURE_MEDIA_NAME_EN)) {
				structureId = String.valueOf(structure.getStructureKey());
				_log.debug("structure " + structure);
				_log.debug("structureId " + structureId);

			}

		}
		
		//Date
		Date startDate = null;
		Date endDate = null;
		
		try {
			if (startDateParam != null && !startDateParam.isEmpty()) {
				startDate = new SimpleDateFormat("dd-MM-yyyy").parse(startDateParam);  
			}
			if (endDateParam != null && !endDateParam.isEmpty()) {
				endDate = new SimpleDateFormat("dd-MM-yyyy").parse(endDateParam);  
			}
			
		} catch (ParseException e) {
			// TODO: luis.correia
			e.printStackTrace();
		}
		
		OrderByComparator<JournalArticle> orderByComparator = null;
		
		if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("displayDate")) {
			orderByComparator = new ArticleDisplayDateComparator(!sorts[0].isReverse());	
		}
		
		else if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("title")) {
			orderByComparator = new JournalArticleTitleComparator(!sorts[0].isReverse());	
		}

		List<Long> ids = new ArrayList<Long>();

		List<JournalArticle> results = search(companyId, groupId, ids, 0, search, null,
				structureId, null, startDate, endDate, 0, null, QueryUtil.ALL_POS, QueryUtil.ALL_POS, orderByComparator);

		List<Media> lastResults = new ArrayList<>();

		for (JournalArticle article : results) {

			_log.debug(article);

			try {

				Media media = new Media(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));

				AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle",
						article.getResourcePrimKey());
				media.setEntryId(assetUtil.getEntryId());

				List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
				
				Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
				
				if (firstCategory.isPresent()) {
					AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
					media.setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
				}

				if ((categoryIdParam == null || categoryIdParam.equalsIgnoreCase("-1")
						|| Long.compare(categoryId, media.getCategory().getCategoryId()) == 0)
						&& (lastResults.indexOf(media) == -1)) {
					lastResults.add(media);
				}

			} catch (PortalException e) {
				_log.error(e.getMessage());
			}
		}

		int paginationSize = pageSize == null ? _app._dxpRESTConfiguration.paginationSize() : pageSize;

		int paginationPage = pagination.getPage();

		int fromIndex = paginationPage != 1 ? ((paginationPage - 1) * paginationSize) : 0;
		int toIndex = paginationPage != 1 ? paginationPage * paginationSize : paginationSize;

		if (toIndex > lastResults.size()) {
			toIndex = lastResults.size();
		}
		
		//order by category
		if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("category"))
		{
			
			if (!sorts[0].isReverse())
			{
				//asc
				lastResults.sort((media1, media2) -> media1.getCategory().getName().compareTo(media2.getCategory().getName()));
			}
			else
			{
				//desc
				lastResults.sort((media1, media2) -> media2.getCategory().getName().compareTo(media1.getCategory().getName()));
			}
		}

		Page<Media> page = Page.of(lastResults.subList(fromIndex, toIndex),
				Pagination.of(pagination.getPage(), paginationSize), lastResults.size());

		String result = null;

		return page;

	}

	/**
	 * 
	 * Returns all galleries
	 * 
	 * @param isRead  with flag read
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("/galleries/{id}")
	@Operation(description = "Get all galleries.")
	@Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "id") })
	@Produces(MediaType.APPLICATION_JSON)
	public GalleryVO getGallery(@Parameter(hidden = true) @PathParam("id") long id, @Context HttpServletRequest request,
			@HeaderParam(Constants.HEADER_GROUP_ID) long groupId) throws PortalException {

		_log.debug("Call get gallery");

		String languageIdString = request.getHeader("languageId");
		String structureKey = StructureUtil.getStructureByNameEn(Constants.STRUCTURE_MEDIA_NAME_EN).getStructureKey();

		//JournalArticle article = JournalArticleLocalServiceUtil.fetchArticle(id);
		JournalArticle article = JournalArticleLocalServiceUtil.getLatestArticle(id);

		GalleryVO result = new GalleryVO(new Media(article, request.getHeader(Constants.HEADER_LANGUAGE_ID)), new ArrayList<String>());
		
		AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle", article.getResourcePrimKey());

		_log.debug("JournalArticle: " + article);
		
		_log.debug("article.getResourcePrimKey(): " + article.getResourcePrimKey());
		
		List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
		
		Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
				
		if (firstCategory.isPresent()) {
			AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
			//promotionDetail.setCategory(catego.getTitle(languageIdString));
			result.getMedia().setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
			_log.debug("categoryName: " + catego.getName());
		}

		if (article == null || !article.getStructureId().equals(structureKey)) {
			// TODO: improve this
			throw new PortalException(javax.ws.rs.core.Response.Status.NOT_FOUND.toString());
		}
		
		try {
			DLFileEntry file = DLFileEntryLocalServiceUtil.getDLFileEntry(result.getMedia().getFileClassPk());

			java.util.List<com.liferay.document.library.kernel.model.DLFileEntry> files = DLFileEntryLocalServiceUtil
					.getFileEntries(groupId, file.getFolderId());

			for (DLFileEntry f : files) {

				result.getSrcs().add(FileUtil.getImageURL(f));

				_log.debug(f);
			}
		} catch (NestableException e) {
			_log.error(e);
		}

		return result;
	}

	/**
	 * 
	 * Mark entity with as read
	 * 
	 * @param entryId id of entity
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@PATCH
	@Path("{entryId}/markRead")
	@Operation(description = "Mark entity as read.")
	@Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "entryId") })
	@Produces(MediaType.APPLICATION_JSON)
	public AnnouncementsFlag getAllAnnouncements(@PathParam("entryId") long entryId,
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("Mark entity as read when id == " + entryId);

		User currentUser = UserUtil.getCurrentUser(request, _app);

		AnnouncementsFlag result = AnnouncementsFlagLocalServiceUtil.addFlag(currentUser.getUserId(), entryId,
				com.liferay.announcements.kernel.model.AnnouncementsFlagConstants.HIDDEN);

		_log.debug("Result == " + result);

		return result;

	}

	/**
	 * 
	 * Utility method for get if the entity is read or not
	 * 
	 * @param entryId entryId id of entity
	 * @param userId  id of entity User
	 * @return
	 */
	private Boolean isRead(long entryId, long userId) {

		DynamicQuery flagDynamicQuery = AnnouncementsFlagLocalServiceUtil.dynamicQuery();

		Property userIdProperty = PropertyFactoryUtil.forName("userId");
		Property entryIdProperty = PropertyFactoryUtil.forName("entryId");
		Property valueProperty = PropertyFactoryUtil.forName("value");

		int[] valuesReadIds = new int[] { com.liferay.announcements.kernel.model.AnnouncementsFlagConstants.HIDDEN };

		flagDynamicQuery.add(valueProperty.in(valuesReadIds));
		flagDynamicQuery.add(entryIdProperty.eq(entryId));
		flagDynamicQuery.add(userIdProperty.eq(userId));

		List<AnnouncementsFlag> flags = AssetEntryLocalServiceUtil.dynamicQuery(flagDynamicQuery);

		return flags.size() > 0;

	}

}
