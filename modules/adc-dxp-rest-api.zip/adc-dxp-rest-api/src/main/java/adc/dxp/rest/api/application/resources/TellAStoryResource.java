package adc.dxp.rest.api.application.resources;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.service.JournalArticleLocalServiceUtil;
import com.liferay.journal.util.comparator.ArticleDisplayDateComparator;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.filter.Filter;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.vulcan.pagination.Page;
import com.liferay.portal.vulcan.pagination.Pagination;

import adc.dxp.rest.api.application.AdcDxpRestApiApplication;
import adc.dxp.rest.api.application.data.Category;
import adc.dxp.rest.api.application.data.TellaStory;
import adc.dxp.rest.api.application.data.comparator.JournalArticleTitleComparator;
import adc.dxp.rest.api.application.data.vo.UserVO;
import adc.dxp.rest.api.application.utils.Constants;
import adc.dxp.rest.api.application.utils.PageUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;

/**
 * 
 * Endpoints  of the Tell a Story
 * 
 * @author ana.cavadas
 *
 */
@Path("/tellastory")
public class TellAStoryResource extends BasicResource {

	
	/**
	 * app instance
	 */
	private AdcDxpRestApiApplication _app;
	
	/**
	 * logging instance
	 */
	private static Log _log = LogFactoryUtil.getLog(NewsResource.class);

	
	/**
	 * 
	 * Constructor, will be used in AdcDxpRestApiApplication.getSingletons()
	 * 
	 * @param _app
	 */
	public TellAStoryResource(AdcDxpRestApiApplication _app) {
		this._app = _app;
	}
	
	@GET
	@Operation(
		description = "Retrieves the list of the Tell a Story. Results can be paginated, filtered, searched, and sorted."
	)
	@Parameters(
		value = {
			@Parameter(in = ParameterIn.QUERY, name = "search"),
			@Parameter(in = ParameterIn.QUERY, name = "filter"),
			@Parameter(in = ParameterIn.QUERY, name = "page"),
			@Parameter(in = ParameterIn.QUERY, name = "pageSize"),
			@Parameter(in = ParameterIn.QUERY, name = "sort")
		}
	)
	@Path("/search")
	@Produces(MediaType.APPLICATION_JSON)
	public Page<TellaStory> search(
			@Parameter(hidden = true) @QueryParam("search") String search,
			@Parameter(hidden = true) @QueryParam("categoryId") String categoryIdParam,
			@Parameter(hidden = true) @QueryParam("startDate") String startDateParam,
			@Parameter(hidden = true) @QueryParam("endDate") String endDateParam,
			@QueryParam("pageSize") Integer pageSize,
			@Context Filter filter, 
			@Context Pagination pagination,
			@Context Sort[] sorts, 
			@Context HttpServletRequest request) throws PortalException {
		
		int paginationSize = pageSize == null ? _app._dxpRESTConfiguration.paginationSize() : pageSize;
		int paginationPage = pagination.getPage();
		
		long companyId = PortalUtil.getCompanyId(request);
		
		String groupIdString = request.getHeader("groupId");
		
		long groupId = Long.valueOf(groupIdString).longValue();
		String languageIdString = request.getHeader("languageId");

		long categoryId = categoryIdParam != null && !categoryIdParam.isEmpty() ? Long.valueOf(categoryIdParam).longValue() : -1;
		
		/*Company company = CompanyLocalServiceUtil.getCompanyByMx(PropsUtil.get(PropsKeys.COMPANY_DEFAULT_WEB_ID));
		long groupId = company.getGroup().getGroupId(); 
		*/
		String structureId = StructureResource.getStructure(groupId, Constants.STRUCTURE_TELL_A_STORY_NAME_EN);
		
		//Date
		Date startDate = null;
		Date endDate = null;
		
		try {
			if (startDateParam != null && !startDateParam.isEmpty()) {
				startDate = new SimpleDateFormat("dd-MM-yyyy").parse(startDateParam);  
			}
			if (endDateParam != null && !endDateParam.isEmpty()) {
				endDate = new SimpleDateFormat("dd-MM-yyyy").parse(endDateParam);  
			}
			
		} catch (ParseException e) {
			// TODO: luis.correia
			
			e.printStackTrace();
		}
		
		OrderByComparator<JournalArticle> orderByComparator = null;
		
		if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("displayDate")) {
			orderByComparator = new ArticleDisplayDateComparator(!sorts[0].isReverse());	
		}
		
		else if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("title")) {
			orderByComparator = new JournalArticleTitleComparator(!sorts[0].isReverse());	
		}

		_log.debug("startDate2: "+ startDate);
		_log.debug("endDate: "+ endDate);
		
		List<JournalArticle> results = search(companyId, groupId, Collections.emptyList(), 0, search, null, 
				structureId, null, startDate, endDate, 0, null, QueryUtil.ALL_POS, QueryUtil.ALL_POS, orderByComparator);
		
		List<TellaStory> lastResults = new ArrayList<>();
		
		for (JournalArticle article: results) {
			TellaStory tellaStory = new TellaStory(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));
			
			//get author by screen name
			User user = UserLocalServiceUtil.fetchUserByScreenName(companyId, tellaStory.getAuthor());
			
			if (user != null) {
				UserVO userVo = new UserVO(user);
				userVo.complementValues();
				tellaStory.setUser(userVo);
				userVo.setContacts(null);
			} else {
				_log.warn("User is null");
			}
			
			AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle", article.getResourcePrimKey());
			tellaStory.setEntryId(assetUtil.getEntryId());
			
			List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
			
			Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
			
			if (firstCategory.isPresent()) {
				AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
				tellaStory.setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
			}
			
			_log.debug("DisplayDate: " + tellaStory.getDisplayDate() );
			_log.debug("ExpirationDate: " + tellaStory.getExpirationDate());
			
			if ((categoryIdParam == null || categoryIdParam.equalsIgnoreCase("-1")
					|| Long.compare(categoryId, tellaStory.getCategory().getCategoryId()) == 0)
					&& (lastResults.indexOf(tellaStory) == -1)) {
				lastResults.add(tellaStory);
			}		
		}
		
		//order by category
		if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("category"))
		{
			
			if (!sorts[0].isReverse())
			{
				//asc
				lastResults.sort((story1, story2) -> story1.getCategory().getName().compareTo(story2.getCategory().getName()));
			}
			else
			{
				//desc
				lastResults.sort((story1, story2) -> story2.getCategory().getName().compareTo(story1.getCategory().getName()));
			}
		}
		
		return PageUtils.getPage(lastResults, paginationSize, paginationPage);
	}
	
	/**
	 * 
	 * Returns story by id
	 * 
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("/detail")
	@Operation(description = "Get story by id")
	@Parameters(
			value = {
				@Parameter(in = ParameterIn.QUERY, name = "id")
			}
		)
	@Produces(MediaType.APPLICATION_JSON)
	public TellaStory getStoryById(
			@Parameter(hidden = true) @QueryParam("id") String idString,
			@Context HttpServletRequest request
			) throws PortalException {

		_log.debug("Call get story");

		String groupIdString = request.getHeader("groupId");
		String languageIdString = request.getHeader("languageId");
		
		long companyId = PortalUtil.getCompanyId(request);
		
		long groupId = Long.valueOf(groupIdString).longValue();
		
		long id = Long.valueOf(idString).longValue();
		
		String structureId = StructureResource.getStructure(groupId, Constants.STRUCTURE_TELL_A_STORY_NAME_EN);

		JournalArticle article = JournalArticleLocalServiceUtil.getLatestArticle(id);
		TellaStory storyDetail = new TellaStory(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));
		
		AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle", article.getResourcePrimKey());

		_log.debug("JournalArticle: " + article);
		
		_log.debug("article.getResourcePrimKey(): " + article.getResourcePrimKey());
				
		//get author by screen name
		User user = UserLocalServiceUtil.fetchUserByScreenName(companyId, storyDetail.getAuthor());

		//get author by email if fail by screen name
		if(user == null) {
			user = UserLocalServiceUtil.fetchUserByEmailAddress(companyId, storyDetail.getAuthorEmail());
		}
		
		if (user != null) {
			UserVO userVo = new UserVO(user);			
			userVo.complementValues();
			userVo.setContacts(null);
			storyDetail.setUser(userVo);
			
		}
		else {
			_log.warn("User is null");
		}		
		
		List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
		
		Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
		
		if (firstCategory.isPresent()) {
			AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
			//storyDetail.setCategory(catego.getTitle(languageIdString));
			storyDetail.setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
			_log.debug("categoryName: " + catego.getName());
		}
		
		if (article == null || !article.getStructureId().equals(structureId)) {
			// TODO: improve this
			_log.debug("Not Found");
			throw new PortalException(javax.ws.rs.core.Response.Status.NOT_FOUND.toString());
		}
		
		return storyDetail;
	}
}
	