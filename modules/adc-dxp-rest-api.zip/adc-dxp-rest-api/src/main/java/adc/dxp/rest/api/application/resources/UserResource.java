package adc.dxp.rest.api.application.resources;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.liferay.portal.kernel.dao.orm.Conjunction;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.Disjunction;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.OrderFactoryUtil;
import com.liferay.portal.kernel.dao.orm.OrderByComparator;
import com.liferay.portal.kernel.dao.orm.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Image;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchContextFactory;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.filter.Filter;
import com.liferay.portal.kernel.service.ImageLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.service.UserServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.LinkedHashMapBuilder;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.webserver.WebServerServletTokenUtil;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.model.impl.UserModelImpl;
import com.liferay.portal.vulcan.pagination.Page;
import com.liferay.portal.vulcan.pagination.Pagination;

import adc.dxp.rest.api.application.AdcDxpRestApiApplication;
import adc.dxp.rest.api.application.data.vo.UserVO;
import adc.dxp.rest.api.application.utils.Constants;
import adc.dxp.rest.api.application.utils.PageUtils;
import adc.dxp.rest.api.application.utils.RequestUtil;
import adc.dxp.rest.api.application.utils.UserUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;

/**
 *
 * Endpoints  of users
 *
 * @author ricardo.gomes
 *
 */
@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
public class UserResource extends BasicResource {

	/**
	 * app instance
	 */
	AdcDxpRestApiApplication _app;

	/**
	 * logging instance
	 */
	private static Log _log = LogFactoryUtil.getLog(UserResource.class);

	/**
	 *
	 * Constructor, will be used in AdcDxpRestApiApplication.getSingletons()
	 *
	 * @param _app
	 */
	public UserResource(AdcDxpRestApiApplication _app) {
		this._app = _app;
	}

	/**
	 * Get current user
	 * @param request hidden parameter
	 * @return Current user
	 * @throws PortalException
	 */
	@GET
	@Path("/currentUser")
	@Operation(description = "Get current user")
	@Produces(MediaType.APPLICATION_JSON)
	public UserModelImpl getCurrentUser(@Context HttpServletRequest request, @HeaderParam(Constants.HEADER_GROUP_ID) long groupId) throws PortalException {

		UserModelImpl currentUser = (UserModelImpl) UserUtil.getCurrentUser(request, _app);

		long portraitId = currentUser.getPortraitId();

		Image image = ImageLocalServiceUtil.getImage(portraitId);

		String tokenId = WebServerServletTokenUtil.getToken(image.getImageId());

		ThemeDisplay themeDisplay= RequestUtil.getTheme(request);

		String portraitURL = null;
		try {
			portraitURL = themeDisplay.getUser().getPortraitURL(themeDisplay);
			_log.debug(themeDisplay);
			_log.debug(portraitURL);
			_log.debug(themeDisplay.getScopeGroupId());
			_log.debug(themeDisplay.getPathImage()+"/user_portrait?img_id="+portraitId);
			_log.debug(groupId);
		} catch (PortalException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SystemException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		//UserVO result = UserMapper.INST.userToUserVO(currentUser);
		return currentUser;

	}

	/**
	 * 
	 * @param searchValue
	 * @param filter
	 * @param pagination
	 * @param sorts
	 * @param request
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("/search")
	@Operation(description = "Search users.")
	@Parameters(value = { 
		@Parameter(in = ParameterIn.QUERY, name = "keywords"),
		@Parameter(in = ParameterIn.QUERY, name = "pageSize")
	})
	@Produces(MediaType.APPLICATION_JSON)
	public Page<UserVO> searchUsers(
			@Parameter(hidden = true) @QueryParam("keywords") String keywords,
			@QueryParam("pageSize") Integer pageSize,
			@Context Filter filter,
			@Context Pagination pagination,
			@Context Sort[] sorts,
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("Searching users with keywords: " + keywords);

		User currentUser = UserUtil.getCurrentUser(request, _app);
		SearchContext searchContext = SearchContextFactory.getInstance(request);
		searchContext.setCompanyId(currentUser.getCompanyId());

		DynamicQuery query = UserLocalServiceUtil.dynamicQuery();
		query.add(PropertyFactoryUtil.forName("companyId").eq(currentUser.getCompanyId()));
		query.add(PropertyFactoryUtil.forName("status").eq(WorkflowConstants.STATUS_APPROVED));

		if (keywords != null && !keywords.isEmpty()) {
			Conjunction conjunction = RestrictionsFactoryUtil.conjunction();
			Disjunction disjunction = RestrictionsFactoryUtil.disjunction();

			disjunction.add(PropertyFactoryUtil.forName("firstName").like("%" + keywords + "%"));
			disjunction.add(PropertyFactoryUtil.forName("lastName").like("%" + keywords + "%"));
			disjunction.add(PropertyFactoryUtil.forName("screenName").like("%" + keywords + "%"));
			disjunction.add(PropertyFactoryUtil.forName("emailAddress").like("%" + keywords + "%"));

			conjunction.add(disjunction);
			query.add(conjunction);
		}

		OrderByComparator<User> orderByComparator = OrderByComparatorFactoryUtil.create(
				"User_", "firstName", true, "lastName", true);
		query.addOrder(OrderFactoryUtil.asc("firstName"));
		query.addOrder(OrderFactoryUtil.asc("lastName"));

		int start = pagination.getStartPosition();
		int end = pagination.getEndPosition();

		List<User> users = UserLocalServiceUtil.dynamicQuery(query, start, end, orderByComparator);
		long total = UserLocalServiceUtil.dynamicQueryCount(query);

		List<UserVO> userVOs = new ArrayList<>();
		for (User user : users) {
			userVOs.add(convertToUserVO(user));
		}

		return PageUtils.createPage(userVOs, pagination, total);
	}

	private UserVO convertToUserVO(User user) {
		UserVO userVO = new UserVO();
		userVO.setUserId(user.getUserId());
		userVO.setFirstName(user.getFirstName());
		userVO.setLastName(user.getLastName());
		userVO.setScreenName(user.getScreenName());
		userVO.setEmailAddress(user.getEmailAddress());
		userVO.setLanguageId(user.getLanguageId());

		String portraitURL = StringPool.BLANK;
		try {
			if (user.getPortraitId() > 0) {
				Image image = ImageLocalServiceUtil.getImage(user.getPortraitId());
				if (image != null) {
					String token = WebServerServletTokenUtil.getToken(user.getPortraitId());
					portraitURL = "/user/" + user.getUserId() + "/portrait?img_id_token=" + token;
				}
			}
		} catch (PortalException e) {
			_log.error("Error getting portrait for user " + user.getUserId(), e);
		}
		userVO.setPortraitURL(portraitURL);

		return userVO;
	}

	/**
	 * 
	 * Returns a user by primary key
	 * 
	 * @param id
	 * @param request
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("/{id}")
	@Operation(description = "Get a user by primary key.")
	@Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "id")})
	@Produces(MediaType.APPLICATION_JSON)
	public UserVO getGallery(
			@Parameter(hidden = true) @PathParam("id") long id,
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("Get user by id "+id);

		User user = UserLocalServiceUtil.fetchUser(id);

		UserVO result = new UserVO(user);
		result.complementValues();
		result.setContacts(null);

		return result;


	}
	
	
	/**
	 * 
	 * Returns a user by screen name
	 * 
	 * @param screenName
	 * @param request
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("/screen-names/{screenName}")
	@Operation(description = "Get a user by screen name.")
	@Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "screenName")})
	@Produces(MediaType.APPLICATION_JSON)
	public UserVO getGallery(
			@Parameter(hidden = true) @PathParam("screenName") String screenName,
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("Get user by screnn name "+screenName);

		
		User userTmp = UserLocalServiceUtil.fetchUserByScreenName(getCompanyId(request), screenName);
		User user = UserLocalServiceUtil.fetchUser(userTmp.getUserId());

		UserVO result = new UserVO(user);
		result.complementValues();
		result.setContacts(null);

		return result;


	}

}