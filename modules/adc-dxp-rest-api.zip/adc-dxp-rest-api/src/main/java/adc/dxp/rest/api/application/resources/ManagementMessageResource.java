package adc.dxp.rest.api.application.resources;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.service.JournalArticleLocalServiceUtil;
import com.liferay.journal.util.comparator.ArticleDisplayDateComparator;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.filter.Filter;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.vulcan.pagination.Page;
import com.liferay.portal.vulcan.pagination.Pagination;

import adc.dxp.rest.api.application.AdcDxpRestApiApplication;
import adc.dxp.rest.api.application.data.Category;
import adc.dxp.rest.api.application.data.DirectorMessage;
import adc.dxp.rest.api.application.data.comparator.JournalArticleTitleComparator;
import adc.dxp.rest.api.application.utils.Constants;
import adc.dxp.rest.api.application.utils.PageUtils;
import adc.dxp.rest.api.application.utils.StructureUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;

/**
 * 
 * Endpoints  of the Management Memssage
 *
 */
@Path("/management-messages")
public class ManagementMessageResource extends BasicResource {

	
	/**
	 * app instance
	 */
	private AdcDxpRestApiApplication _app;
	
	/**
	 * logging instance
	 */
	private static Log _log = LogFactoryUtil.getLog(NewsResource.class);

	
	/**
	 * 
	 * Constructor, will be used in AdcDxpRestApiApplication.getSingletons()
	 * 
	 * @param _app
	 */
	public ManagementMessageResource(AdcDxpRestApiApplication _app) {
		this._app = _app;
	}
	
	@GET
	@Operation(
		description = "Retrieves the list of the Director Message. Results can be paginated, filtered, searched, and sorted."
	)
	@Parameters(
		value = {
			@Parameter(in = ParameterIn.QUERY, name = "search"),
			@Parameter(in = ParameterIn.QUERY, name = "filter"),
			@Parameter(in = ParameterIn.QUERY, name = "page"),
			@Parameter(in = ParameterIn.QUERY, name = "pageSize"),
			@Parameter(in = ParameterIn.QUERY, name = "sort")
		}
	)
	@Path("")
	@Produces(MediaType.APPLICATION_JSON)
	public Page<DirectorMessage> search(
			@Parameter(hidden = true) @QueryParam("id") String idString,
			@Parameter(hidden = true) @QueryParam("search") String search,
			@Parameter(hidden = true) @QueryParam("categoryId") String categoryIdParam,
			@Parameter(hidden = true) @QueryParam("startDate") String startDateParam,
			@Parameter(hidden = true) @QueryParam("endDate") String endDateParam,
			@QueryParam("pageSize") Integer pageSize,
			@Context Filter filter, 
			@Context Pagination pagination,
			@Context Sort[] sorts, 
			@Context HttpServletRequest request) throws PortalException {
		
		int paginationSize = pageSize == null ? _app._dxpRESTConfiguration.paginationSize() : pageSize;
		int paginationPage = pagination.getPage();
		
		long companyId = PortalUtil.getCompanyId(request);
		
		String groupIdString = request.getHeader("groupId");

		long id = idString != null && !idString.isEmpty() && !idString.equalsIgnoreCase("null") ? Long.valueOf(idString).longValue(): -1;
		
		long groupId = Long.valueOf(groupIdString).longValue();
		String languageIdString = request.getHeader("languageId");

		long categoryId = categoryIdParam != null && !categoryIdParam.isEmpty() ? Long.valueOf(categoryIdParam).longValue() : -1;
		
		String structureId = StructureUtil.getStructureByNameEn(Constants.STRUCTURE_MANAGEMENT_MESSAGE_NAME_EN)
				.getStructureKey();

		Date startDate = null;
		Date endDate = null;
		
		try {
			if (startDateParam != null && !startDateParam.isEmpty()) {
				startDate = new SimpleDateFormat("dd-MM-yyyy").parse(startDateParam);  
			}
			if (endDateParam != null && !endDateParam.isEmpty()) {
				endDate = new SimpleDateFormat("dd-MM-yyyy").parse(endDateParam);  
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		OrderByComparator<JournalArticle> orderByComparator = null;
		
		if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("displayDate")) {
			orderByComparator = new ArticleDisplayDateComparator(!sorts[0].isReverse());	
		}
		
		else if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("title")) {
			orderByComparator = new JournalArticleTitleComparator(!sorts[0].isReverse());	
		}

		_log.debug("startDate2s: "+ startDate);
		_log.debug("endDate: "+ endDate);
		
		List<JournalArticle> results = search(companyId, groupId, Collections.emptyList(), 0, search, null, 
				structureId, null, startDate, endDate, 0, null, QueryUtil.ALL_POS, QueryUtil.ALL_POS, orderByComparator);
		
		List<DirectorMessage> lastResults = new ArrayList<>();
		
		for (JournalArticle article: results) {
			
			DirectorMessage tellaStory = new DirectorMessage(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));
			
			_log.debug("idString: "+ idString);
			_log.debug("tellaStory.getResourcePrimaryKey(): "+ tellaStory.getResourcePrimaryKey());
			_log.debug("id: "+ id);
			
			AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle", article.getResourcePrimKey());
			tellaStory.setEntryId(assetUtil.getEntryId());
			
			List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
			
			Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
			
			if (firstCategory.isPresent()) {
				AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
				tellaStory.setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
			}
			
			_log.debug("DisplayDate: " + tellaStory.getDisplayDate() );
			_log.debug("ExpirationDate: " + tellaStory.getExpirationDate());
			
			if ((categoryIdParam == null || categoryIdParam.equalsIgnoreCase("-1")
					|| Long.compare(categoryId, tellaStory.getCategory().getCategoryId()) == 0)
					&& (lastResults.indexOf(tellaStory) == -1) && !(Long.compare(tellaStory.getResourcePrimaryKey(), id) == 0)) {
					lastResults.add(tellaStory);		
			}

		}
		
		//order by category
		if (sorts != null && sorts[0].getFieldName().equalsIgnoreCase("category"))
		{
			
			if (!sorts[0].isReverse())
			{
				//asc
				lastResults.sort((entity1, entity2) -> entity1.getCategory().getName().compareTo(entity2.getCategory().getName()));
			}
			else
			{
				//desc
				lastResults.sort((entity1, entity2) -> entity2.getCategory().getName().compareTo(entity1.getCategory().getName()));
			}
		}
		
		List<DirectorMessage> finalResult = new ArrayList<>();
		
		if ((idString == null || idString.isEmpty()) && pageSize > 1) {			
			finalResult = lastResults.subList(1, lastResults.size());
		} else {
			finalResult = lastResults;
		}
		
		return PageUtils.getPage(finalResult, paginationSize, paginationPage);
	}
	
	/**
	 * 
	 * Returns Management message by id
	 * 
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("/{entryId}")
	@Operation(description = "Get a management message by id")
	@Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "entryId") })
	@Produces(MediaType.APPLICATION_JSON)
	public DirectorMessage getStoryById(
			@Parameter(hidden = true) @PathParam("entryId") long entryId,
			@Context HttpServletRequest request
			) throws PortalException {

		_log.debug("Call get a management message");

		String groupIdString = request.getHeader("groupId");
		String languageIdString = request.getHeader("languageId");
		
		long companyId = PortalUtil.getCompanyId(request);
		
		long groupId = Long.valueOf(groupIdString).longValue();
		
		String structureId = StructureUtil.getStructureByNameEn(Constants.STRUCTURE_MANAGEMENT_MESSAGE_NAME_EN)
				.getStructureKey();

		JournalArticle article = JournalArticleLocalServiceUtil.getLatestArticle(entryId);
		DirectorMessage entity = new DirectorMessage(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));
		
		AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle", article.getResourcePrimKey());

		_log.debug("JournalArticle: " + article);
		
		_log.debug("article.getResourcePrimKey(): " + article.getResourcePrimKey());
				
		List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
		
		Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
		
		if (firstCategory.isPresent()) {
			AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
			entity.setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
			_log.debug("categoryName: " + catego.getName());
		}
		
		if (article == null || !article.getStructureId().equals(structureId)) {
			_log.debug("Not Found");
			throw new PortalException(javax.ws.rs.core.Response.Status.NOT_FOUND.toString());
		}
		
		return entity;
	}
}
	