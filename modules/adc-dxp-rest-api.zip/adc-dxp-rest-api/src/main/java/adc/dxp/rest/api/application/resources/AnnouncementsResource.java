package adc.dxp.rest.api.application.resources;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PATCH;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.liferay.announcements.kernel.model.AnnouncementsEntry;
import com.liferay.announcements.kernel.model.AnnouncementsFlag;
import com.liferay.announcements.kernel.service.AnnouncementsEntryLocalServiceUtil;
import com.liferay.announcements.kernel.service.AnnouncementsFlagLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.service.JournalArticleLocalServiceUtil;
import com.liferay.journal.util.comparator.ArticleDisplayDateComparator;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.OrderByComparator;
import com.liferay.portal.kernel.dao.orm.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.model.UserNotificationDeliveryConstants;
import com.liferay.portal.kernel.model.UserNotificationEvent;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchContextFactory;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.filter.Filter;
import com.liferay.portal.kernel.service.UserNotificationEventLocalServiceUtil;
import com.liferay.portal.kernel.service.WorkflowInstanceLinkLocalServiceUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.vulcan.pagination.Page;
import com.liferay.portal.vulcan.pagination.Pagination;

import adc.dxp.rest.api.application.AdcDxpRestApiApplication;
import adc.dxp.rest.api.application.data.Announcements;
import adc.dxp.rest.api.application.data.Category;
import adc.dxp.rest.api.application.data.News;
import adc.dxp.rest.api.application.data.TellaStory;
import adc.dxp.rest.api.application.data.comparator.JournalArticleTitleComparator;
import adc.dxp.rest.api.application.utils.Constants;
import adc.dxp.rest.api.application.utils.PageUtils;
import adc.dxp.rest.api.application.utils.StructureUtil;
import adc.dxp.rest.api.application.utils.UserUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;

import com.liferay.petra.string.StringPool;

/**
 * 
 * Endpoints of announcements
 * 
 * @author ricardo.gomes
 *
 */
@Path("/announcements")
public class AnnouncementsResource extends BasicResource {

	/**
	 * logging instance
	 */
	private static Log _log = LogFactoryUtil.getLog(AnnouncementsResource.class);

	/**
	 * app instance
	 */
	AdcDxpRestApiApplication _app;

	/**
	 * 
	 * Constructor, will be used in AdcDxpRestApiApplication.getSingletons()
	 * 
	 * @param _app
	 */
	public AnnouncementsResource(AdcDxpRestApiApplication _app) {
		this._app = _app;
	}

	/**
	 * 
	 * Returns all announcements
	 * 
	 * @param isRead  with flag read
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("")
	@Operation(description = "Get all announcements.")
	@Parameters(value = { @Parameter(in = ParameterIn.QUERY, name = "isRead") })
	@Produces(MediaType.APPLICATION_JSON)
	public List<AnnouncementsEntry> getAllAnnouncements(@Parameter(hidden = true) @QueryParam("isRead") Boolean isRead,
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("Get all announcements with isRead == " + isRead);

		List<AnnouncementsEntry> result = new ArrayList<>();

		User currentUser = UserUtil.getCurrentUser(request, _app);

		DynamicQuery adq = AnnouncementsEntryLocalServiceUtil.dynamicQuery();

		Property userIdProperty = PropertyFactoryUtil.forName("userId");
		Property displayDateProperty = PropertyFactoryUtil.forName("displayDate");
		Property expirationDateProperty = PropertyFactoryUtil.forName("expirationDate");
		Property companyIdProperty = PropertyFactoryUtil.forName("companyId");

		adq.add(userIdProperty.eq(currentUser.getUserId()));
		adq.add(companyIdProperty.eq(currentUser.getCompanyId()));
		adq.add(displayDateProperty.le(new Date()));
		adq.add(expirationDateProperty.ge(new Date()));

		List<AnnouncementsEntry> entries = AnnouncementsEntryLocalServiceUtil.dynamicQuery(adq);

		_log.debug(entries + " entries found");

		for (AnnouncementsEntry e : entries) {
			if (isRead == null || isRead.equals(isRead(e.getEntryId(), currentUser.getUserId()))) {
				_log.debug(e + " added to result ");
				result.add(e);
			}
		}
		return result;
	}

	/**
	 * 
	 * Mark entity with as read
	 * 
	 * @param entryId id of entity
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@PATCH
	@Path("{entryId}/markRead")
	@Operation(description = "Mark entity as read.")
	@Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "entryId") })
	@Produces(MediaType.APPLICATION_JSON)
	public AnnouncementsFlag markAnnouncementRead(@PathParam("entryId") long entryId,
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("Mark entity as read when id == " + entryId);

		User currentUser = UserUtil.getCurrentUser(request, _app);

		AnnouncementsFlag result = AnnouncementsFlagLocalServiceUtil.addFlag(currentUser.getUserId(), entryId,
				com.liferay.announcements.kernel.model.AnnouncementsFlagConstants.HIDDEN);

		_log.debug("Result == " + result);

		return result;
	}

	/**
	 * 
	 * Utility method for get if the entity is read or not
	 * 
	 * @param entryId entryId id of entity
	 * @param userId  id of entity User
	 * @return
	 */
	private Boolean isRead(long entryId, long userId) {

		DynamicQuery flagDynamicQuery = AnnouncementsFlagLocalServiceUtil.dynamicQuery();

		Property userIdProperty = PropertyFactoryUtil.forName("userId");
		Property entryIdProperty = PropertyFactoryUtil.forName("entryId");
		Property valueProperty = PropertyFactoryUtil.forName("value");

		int[] valuesReadIds = new int[] { com.liferay.announcements.kernel.model.AnnouncementsFlagConstants.HIDDEN };

		flagDynamicQuery.add(valueProperty.in(valuesReadIds));
		flagDynamicQuery.add(entryIdProperty.eq(entryId));
		flagDynamicQuery.add(userIdProperty.eq(userId));

		List<AnnouncementsFlag> flags = AnnouncementsFlagLocalServiceUtil.dynamicQuery(flagDynamicQuery);

		return flags.size() > 0;

	}

	/**
	 * 
	 * @param onlyIsNotRead
	 * @param request
	 * @return all web content with announcements structureId
	 * @throws PortalException
	 */
	@GET
	@Path("/web-content")
	@Operation(description = "Get all announcements from web content.")
	@Parameters(value = { 
		@Parameter(in = ParameterIn.QUERY, name = "onlyIsNotRead"),
		@Parameter(in = ParameterIn.QUERY, name = "search"),
		@Parameter(in = ParameterIn.QUERY, name = "categoryId"),
		@Parameter(in = ParameterIn.QUERY, name = "startDate"),
		@Parameter(in = ParameterIn.QUERY, name = "endDate"),
		@Parameter(in = ParameterIn.QUERY, name = "pageSize")
	})
	@Produces(MediaType.APPLICATION_JSON)
	public Page<Announcements> getAllAnnouncementsFromWebContent(
			@Parameter(hidden = true) @QueryParam("onlyIsNotRead") Boolean onlyIsNotRead,
			@Parameter(hidden = true) @QueryParam("search") String search,
			@Parameter(hidden = true) @QueryParam("categoryId") String categoryIdParam,
			@Parameter(hidden = true) @QueryParam("startDate") String startDateParam,
			@Parameter(hidden = true) @QueryParam("endDate") String endDateParam,
			@QueryParam("pageSize") Integer pageSize,
			@Context Filter filter,
			@Context Pagination pagination,
			@Context Sort[] sorts,
			@Context HttpServletRequest request,
			@HeaderParam(Constants.HEADER_GROUP_ID) long groupId) throws PortalException {

		_log.debug("Get all announcements from web content with onlyIsNotRead == " + onlyIsNotRead);

		User currentUser = UserUtil.getCurrentUser(request, _app);
		SearchContext searchContext = SearchContextFactory.getInstance(request);
		searchContext.setCompanyId(currentUser.getCompanyId());
		searchContext.setGroupIds(new long[] { groupId });

		if (search != null && !search.isEmpty()) {
			searchContext.setKeywords(search);
		}

		DynamicQuery query = JournalArticleLocalServiceUtil.dynamicQuery();
		query.add(PropertyFactoryUtil.forName("groupId").eq(groupId));
		query.add(PropertyFactoryUtil.forName("status").eq(WorkflowConstants.STATUS_APPROVED));

		if (categoryIdParam != null && !categoryIdParam.isEmpty()) {
			long categoryId = GetterUtil.getLong(categoryIdParam);
			if (categoryId > 0) {
				List<Long> assetEntryIds = getAssetEntryIdsByCategoryId(categoryId);
				if (!assetEntryIds.isEmpty()) {
					query.add(PropertyFactoryUtil.forName("resourcePrimKey").in(assetEntryIds));
				}
			}
		}

		if (startDateParam != null && !startDateParam.isEmpty()) {
			try {
				Date startDate = new SimpleDateFormat("yyyy-MM-dd").parse(startDateParam);
				query.add(PropertyFactoryUtil.forName("displayDate").ge(startDate));
			} catch (ParseException e) {
				_log.error("Error parsing startDate", e);
			}
		}

		if (endDateParam != null && !endDateParam.isEmpty()) {
			try {
				Date endDate = new SimpleDateFormat("yyyy-MM-dd").parse(endDateParam);
				query.add(PropertyFactoryUtil.forName("displayDate").le(endDate));
			} catch (ParseException e) {
				_log.error("Error parsing endDate", e);
			}
		}

		OrderByComparator<JournalArticle> orderByComparator = OrderByComparatorFactoryUtil.create(
				"JournalArticle", "displayDate", false);
		query.addOrder(OrderFactoryUtil.desc("displayDate"));

		int start = pagination.getStartPosition();
		int end = pagination.getEndPosition();

		List<JournalArticle> articles = JournalArticleLocalServiceUtil.dynamicQuery(query, start, end, orderByComparator);
		long total = JournalArticleLocalServiceUtil.dynamicQueryCount(query);

		List<Announcements> announcements = new ArrayList<>();
		for (JournalArticle article : articles) {
			announcements.add(convertToAnnouncement(article, currentUser.getLanguageId()));
		}

		return PageUtils.createPage(announcements, pagination, total);
	}

	/**
	 * 
	 * @param onlyIsNotRead
	 * @param request
	 * @return all web content with announcements structureId and notification
	 * @throws PortalException
	 */
	@GET
	@Path("/web-content/notifications")
	@Operation(description = "Get all announcements with notification.")
	@Parameters(value = { @Parameter(in = ParameterIn.QUERY, name = "onlyIsNotRead") })
	@Produces(MediaType.APPLICATION_JSON)
	public List<Announcements> getAllAnnouncementsFromWebContentWithNotifications(
			@Parameter(hidden = true) @DefaultValue("true") @QueryParam("onlyIsNotRead") Boolean onlyIsNotRead,
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("..... Get all announcements with notification. ");

		User currentUser = UserUtil.getCurrentUser(request, _app);

		List<UserNotificationEvent> notifications = new ArrayList<UserNotificationEvent>();

		List<UserNotificationEvent> notificationsToProcess = new ArrayList<UserNotificationEvent>();
		
		String languageIdRequest = request.getHeader(Constants.HEADER_LANGUAGE_ID);

		// TODO improve this with dynamic query
//		notifications = UserNotificationEventLocalServiceUtil.getTypeNotificationEvents(_app._dxpRESTConfiguration.announcementsPortletID());
//		notifications = UserNotificationEventLocalServiceUtil.getTypeNotificationEvents(Constants.NOTIFICATION_TYPE_WORKFLOW);
		notifications = UserNotificationEventLocalServiceUtil.getUserNotificationEvents(currentUser.getUserId()); 
		
		/*String structureKey = StructureUtil.getStructureByNameEn(Constants.STRUCTURE_ANNOUNCEMENT_NAME_EN)
				.getStructureKey();*/
		
		String groupIdString = request.getHeader("groupId");
		String defaultGroupId = GetterUtil.get(PropsUtil.get("default-group-id"), "0");
		
		long groupId = groupIdString != null ? Long.valueOf(groupIdString).longValue() : Long.valueOf(defaultGroupId).longValue();
		
		String structureId = StructureResource.getStructure(groupId, Constants.STRUCTURE_ANNOUNCEMENT_NAME_EN);
		
		long structureIdAnnoucement = GetterUtil.get(PropsUtil.get("structure-id-announcement"), 0L);

		List<Announcements> lastResults = new ArrayList<Announcements>();

		for (UserNotificationEvent n : notifications) {

			if (onlyIsNotRead && n.isArchived()) {
				continue;
			}

			JSONObject payload = JSONFactoryUtil.createJSONObject(n.getPayload());

			if (!payload.has("entryClassPK")) {
				continue;
			}

			
			String articleStructureID = (String) payload.get("structureId");
			
			if (!payload.has("structureId") || !(articleStructureID.equalsIgnoreCase(String.valueOf(structureIdAnnoucement)))) {
				continue;
			}

			
			JournalArticle article = JournalArticleLocalServiceUtil.fetchArticle(groupId, payload.getString("entryClassPK"));
			
					
			
			if (article == null || article.getStatus() != WorkflowConstants.STATUS_APPROVED || 
					article.getDDMStructure() == null || article.getDDMStructure().getStructureKey() == null 
					//|| Long.getLong(article.getDDMStructure().getStructureId()) == null ||
					//!(article.getDDMStructure().getStructureId() == structureIdAnnoucement)
					) {
				continue;
			}

			try {

				Announcements announcements = new Announcements(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));

				AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle",
						article.getResourcePrimKey());
				announcements.setEntryId(assetUtil.getEntryId());

				if (lastResults.indexOf(announcements) == -1) {
					lastResults.add(announcements);
				} 

			} catch (PortalException e) {
				_log.error(e.getMessage());
			}

			_log.debug(n);

		}

		_log.debug("result with nr records: " + lastResults.size());

		return lastResults;

	}

	/**
	 * 
	 * Mark entity with as read
	 * 
	 * @param entryId id of entity
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@PATCH
	@Path("/web-content/{entryId}/read")
	@Operation(description = "Mark entity as read.")
	@Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "entryId") })
	@Produces(MediaType.APPLICATION_JSON)
	public List<UserNotificationEvent> markWebContentRead(@PathParam("entryId") long entryId,
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("Mark entity as read when id == " + entryId);

		User currentUser = UserUtil.getCurrentUser(request, _app);

		List<UserNotificationEvent> notifications = new ArrayList<UserNotificationEvent>();

		// TODO improve this with dynamic query
//		notifications = UserNotificationEventLocalServiceUtil.getTypeNotificationEvents(_app._dxpRESTConfiguration.announcementsPortletID());
//		notifications = UserNotificationEventLocalServiceUtil.getTypeNotificationEvents(Constants.NOTIFICATION_TYPE_WORKFLOW);
		notifications = UserNotificationEventLocalServiceUtil.getUserNotificationEvents(currentUser.getUserId());

		String structureKey = StructureUtil.getStructureByNameEn(Constants.STRUCTURE_ANNOUNCEMENT_NAME_EN)
				.getStructureKey();

		_log.debug("..... notifications.size(); " + notifications.size());

		String groupIdString = request.getHeader("groupId");
		String defaultGroupId = GetterUtil.get(PropsUtil.get("default-group-id"), "0");
		
		long groupId = groupIdString != null ? Long.valueOf(groupIdString).longValue() : Long.valueOf(defaultGroupId).longValue();
		
		String structureId = StructureResource.getStructure(groupId, Constants.STRUCTURE_ANNOUNCEMENT_NAME_EN);
		
		long structureIdAnnoucement = GetterUtil.get(PropsUtil.get("structure-id-announcement"), 0L);
		
		List<UserNotificationEvent> result = new ArrayList<UserNotificationEvent>();

		for (UserNotificationEvent n : notifications) {

			JSONObject payload = JSONFactoryUtil.createJSONObject(n.getPayload());

			if (!payload.has("entryClassPK") || payload.getLong("entryClassPK") != entryId) {
				continue;
			}

			JournalArticle article = JournalArticleLocalServiceUtil.fetchArticle(payload.getLong("entryClassPK"));

			/*if (article == null || !article.getStructureId().equals(structureKey)) {
				continue;
			}*/
			
			String articleStructureID = (String) payload.get("structureId");
			
			
			if (!payload.has("structureId") || !(articleStructureID.equalsIgnoreCase(String.valueOf(structureIdAnnoucement)))) {
				continue;
			}

			try {

				n.setArchived(true);

				result.add(UserNotificationEventLocalServiceUtil.updateUserNotificationEvent(n));

			} catch (Exception e) {
				_log.error(e.getMessage());
			}

			_log.debug(n);

		}

		_log.debug("result with nr records: " + result.size());

		return result;

	}
	
	/**
	 * 
	 * Mark entity with as read
	 * 
	 * @param entryId id of entity
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@GET
	@Path("/web-content/{entryId}")
	@Operation(description = "Fetch a announcement.")
	@Parameters(value = { @Parameter(in = ParameterIn.PATH, name = "entryId") })
	@Produces(MediaType.APPLICATION_JSON)
	public Announcements fetchAnnouncement(@PathParam("entryId") long entryId,
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("Feth the announcement " + entryId);

		String groupIdString = request.getHeader("groupId");
		String languageIdString = request.getHeader("languageId");
		
		JournalArticle article = JournalArticleLocalServiceUtil.getLatestArticle(entryId);
		
		Announcements announcement = new Announcements(article, request.getHeader(Constants.HEADER_LANGUAGE_ID));
		
		AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle", article.getResourcePrimKey());
				
		List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
		
		Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
		
		if (firstCategory.isPresent()) {
			AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
			announcement.setCategory(new Category(catego.getTitle(languageIdString), catego.getCategoryId()));
		}
		
		return announcement;

	}
	
	
	/**
	 * 
	 * Mark entity with as read
	 * 
	 * @param entryId id of entity
	 * @param request hidden parameter
	 * @return
	 * @throws PortalException
	 */
	@PATCH
	@Path("/web-content/unread")
	@Operation(description = "Mark entity as read.")
	@Produces(MediaType.APPLICATION_JSON)
	public List<UserNotificationEvent> markWebContentUnRead(
			@Context HttpServletRequest request) throws PortalException {

		_log.debug("Mark all entity as uread ");

		User currentUser = UserUtil.getCurrentUser(request, _app);

		List<UserNotificationEvent> notifications = new ArrayList<UserNotificationEvent>();

		notifications = UserNotificationEventLocalServiceUtil.getUserNotificationEvents(currentUser.getUserId());

		String structureKey = StructureUtil.getStructureByNameEn(Constants.STRUCTURE_ANNOUNCEMENT_NAME_EN)
				.getStructureKey();

		_log.debug("..... notifications.size(); " + notifications.size());

		List<UserNotificationEvent> result = new ArrayList<UserNotificationEvent>();

		for (UserNotificationEvent n : notifications) {

			JSONObject payload = JSONFactoryUtil.createJSONObject(n.getPayload());

			if (!payload.has("entryClassPK")) {
				continue;
			}

			JournalArticle article = JournalArticleLocalServiceUtil.fetchArticle(payload.getLong("entryClassPK"));

			/*if (article == null || !article.getStructureId().equals(structureKey)) {
				continue;
			}*/
			
			String articleStructureID = (String) payload.get("structureId");
			
			if (!payload.has("structureId") || !(articleStructureID.equalsIgnoreCase(String.valueOf(structureIdAnnoucement)))) {
				continue;
			}

			try {
				n.setArchived(false);
				result.add(UserNotificationEventLocalServiceUtil.updateUserNotificationEvent(n));
			} catch (Exception e) {
				_log.error(e.getMessage());
			}

			_log.debug(n);

		}

		_log.debug("result with nr records: " + result.size());

		return result;

	}

	private Announcements convertToAnnouncement(JournalArticle article, String languageId) {
		Announcements announcement = new Announcements(article, languageId);
		AssetEntry assetUtil = AssetEntryLocalServiceUtil.getEntry("com.liferay.journal.model.JournalArticle", article.getResourcePrimKey());
		announcement.setEntryId(assetUtil.getEntryId());
		List<AssetCategory> categoryList = AssetCategoryLocalServiceUtil.getAssetEntryAssetCategories(assetUtil.getEntryId());
		Optional<AssetCategory> firstCategory = categoryList.stream().findFirst();
		if (firstCategory.isPresent()) {
			AssetCategory catego = AssetCategoryLocalServiceUtil.getCategory(firstCategory.get().getCategoryId());
			announcement.setCategory(new Category(catego.getTitle(languageId), catego.getCategoryId()));
		}
		return announcement;
	}

	private List<Long> getAssetEntryIdsByCategoryId(long categoryId) {
		List<Long> assetEntryIds = new ArrayList<>();
		List<AssetCategory> categories = AssetCategoryLocalServiceUtil.getCategories(categoryId);
		for (AssetCategory category : categories) {
			List<AssetEntry> assetEntries = AssetEntryLocalServiceUtil.getAssetEntries(category.getCategoryId());
			for (AssetEntry assetEntry : assetEntries) {
				assetEntryIds.add(assetEntry.getEntryId());
			}
		}
		return assetEntryIds;
	}
}
