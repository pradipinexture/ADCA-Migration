package adc.dxp.rest.api.application.data.mapper;

import com.liferay.announcements.kernel.model.AnnouncementsEntry;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import adc.dxp.rest.api.application.data.vo.AnnouncementsVO;

/**
 * 
 * Mapper of Announcements
 * 
 * @author ricardo.gomes
 *
 */
@Mapper
public interface AnnouncementsMapper {

    AnnouncementsMapper INST = Mappers.getMapper(AnnouncementsMapper.class);

    /**
     * 
     * converts AnnouncementsVO to AnnouncementsEntry
     * 
     * @param announcementsVO
     * @return
     */
    AnnouncementsEntry announcementsVOToAnnouncementsEntryEntry(AnnouncementsVO announcementsVO);
    
    /**
     * 
     * converts AnnouncementsEntry to AnnouncementsVO
     * 
     * @param announcementsEntry
     * @return
     */
    AnnouncementsVO announcementsEntryToAnnouncementsVO(AnnouncementsEntry announcementsEntry);
	
}