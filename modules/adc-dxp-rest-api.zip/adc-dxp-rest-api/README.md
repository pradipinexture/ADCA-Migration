# adc-dxp-social-media

Social Media Homepage

# Build

    gradle build

# Deploy

    Copy adc-dxp-rest-api/build/libs/*.jar to $LIFERAY_HOME/osgi/modules or $LIFERAY_HOME/deploy