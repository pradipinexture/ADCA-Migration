package adc.dxp.rest.api.application.data.vo;

public class UserInternalVO {
    private long userId;
    private String screenName;
}