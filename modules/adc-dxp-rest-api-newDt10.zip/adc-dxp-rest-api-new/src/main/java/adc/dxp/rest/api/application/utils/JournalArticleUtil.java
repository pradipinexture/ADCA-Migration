package adc.dxp.rest.api.application.utils;

import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.service.JournalArticleLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.workflow.WorkflowConstants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class JournalArticleUtil {
    List<JournalArticle> searchJournalArticles(
            long companyId, long groupId, String search, String structureId,
            Date startDate, Date endDate, OrderByComparator<JournalArticle> orderByComparator) {

        try {
            // First get articles by structure ID
            List<JournalArticle> articles = JournalArticleLocalServiceUtil.getArticlesByStructureId(
                    groupId,
                    GetterUtil.getLong(structureId),
                    WorkflowConstants.STATUS_APPROVED,  // Or use appropriate status constant
                    QueryUtil.ALL_POS,
                    QueryUtil.ALL_POS,
                    orderByComparator
            );

            // Filter by search term, company ID, and date range if needed
            List<JournalArticle> filteredResults = new ArrayList<>();

            for (JournalArticle article : articles) {
                // Skip if company ID doesn't match
                if (article.getCompanyId() != companyId) {
                    continue;
                }

                // Skip if outside date range
                if (startDate != null && article.getModifiedDate().before(startDate)) {
                    continue;
                }
                if (endDate != null && article.getModifiedDate().after(endDate)) {
                    continue;
                }

                // Skip if doesn't match search term
                if (Validator.isNotNull(search) &&
                        !StringUtil.containsIgnoreCase(article.getTitle(), search) &&
                        !StringUtil.containsIgnoreCase(article.getDescription(), search) &&
                        !StringUtil.containsIgnoreCase(article.getContent(), search)) {
                    continue;
                }

                filteredResults.add(article);
            }

            return filteredResults;
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }
}
